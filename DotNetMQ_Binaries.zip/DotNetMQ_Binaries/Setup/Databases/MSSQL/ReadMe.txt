To create MS SQL Server database for DotNetMQ, fallow one of two option below:

 First option  : Create a database in SQL Server named mds and run query in Tables.txt file.
 Second option : Unzip DB-FILES.zip and attach to SQL Server.

After creating database, you must configure MDSSettings.xml to use MS SQL Server as DB engine in DotNetMQ.